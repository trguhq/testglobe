Testglobe - Amiga chipset / RTG palette correction and dithering control

Built from source revision 206633cc5398aafae347d6bff50e561d3600f97c plus the included source.patch.
Source: https://github.com/trguhq/testglobe/tree/206633cc5398aafae347d6bff50e561d3600f97c
Apply source.patch at that revision with git apply source.patch, then build
with the VBCC toolchain and make amiga AMI_RTG=1.

Changes:
- D/d toggles palette dithering (on by default). Off selects the nearest
  solid palette color. OSD shows dither on/off, or n/a for truecolor RTG.
- Improve two-pen color mixtures at all supported indexed Workbench depths,
  from 2 to 256 colors, including palettes with fewer usable entries.
- Use exact discrete RGB-mean matching for up to 16 palette entries and a
  bounded two-pass improvement for larger palettes.
- Keep exact palette matches solid and reuse precomputed Bayer patterns.
- Retain the original quad counts, desktop palette, and truecolor RTG path.

Copy testglobe-amiga and testglobe-amiga.info to the same directory on your
Amiga and double-click the icon. The icon selects a 32768-byte launch stack.
For Shell launch:
  Stack 32768
  testglobe-amiga
If needed after transfer: Protect testglobe-amiga +e

All Earth maps are embedded. Keep the executable accessible during execution
and do not strip its debug records, which contain the map data.

Native path: AmigaOS 1.3 or later, 68000 or later, OCS/ECS/AGA Workbench.
Optional RTG: AmigaOS 3.0 or later with CyberGraphX V40 or Picasso96API V2.
No FPU is required; CPU/FPU detection selects the appropriate transform path.
HAM, EHB, and dual-playfield screen modes remain unsupported.
Default globe resolution is key 1; keys 1 through 5 select resolution.

Built with VBCC 0.9h / m68k generator 1.15, vasm 1.9d, vlink 0.17a,
NDK 47.5 headers and the kick13 runtime. RTG support is enabled.
Native-only and RTG-enabled cross-builds passed. Host tests cover all indexed
depths, palette matching, dithering controls/state persistence, CPU/FPU
dispatch, lifecycle and RTG rendering paths.
The executable's Hunk structure, embedded data and icon were verified.
Not executed on Amiga hardware or an Amiga emulator.

See LICENSE and the source repository for licensing and build instructions.
