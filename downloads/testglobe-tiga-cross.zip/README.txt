TIGA / real-mode DOS, 640x480 indexed color

testglobe development cross-build, 2026-11-07

Source and build instructions:
https://github.com/trguhq/testglobe/tree/develop
Use the repository revision containing this ZIP to obtain its corresponding source.
Application source license: GPL-3.0-or-later (see LICENSE).

Validation:
- All four actual cross-build targets compiled and linked successfully.
- Executable formats and required embedded Earth data were inspected.
- Full host regression suite passed (1,363 PASS results), including the existing
  drivers, SDK contracts, geometry, resource lifetimes, and DOS CPU probe.
- The original Linux OpenGL target still compiles and links.
- Host tests do not establish physical graphics output or native desktop behavior.

Compiler: OpenWatcom 2.0 beta, 2026-11-06; TI GSP C 5.01 tools under DOSBox

Build: make tiga-cross

Requirements: DOS, a TIGA 2.x board/runtime offering 640x480 8-bit color, and its
installed TIGACD communication driver/graphics manager/standard primitives.
The application and its Earth maps are in TESTGLOB.EXE. The TI transform module
is embedded too; no separate TGA_GSP.RLM needs to be distributed.

Software 3D is the default. S toggles TI-processor transforms and host transforms.
TIGA's loader needs a temporary extracted module file; if extraction/loading
fails, the application continues with host transforms and board polygon filling.
No x87 is required. CPU/FPU detection selects supported host transform kernels.
Keys 1-2 select Earth resolution; default is 1. A/F/O toggle rotation/FPS/OSD;
Escape exits. There is no texture mode.

Both maps and the embedded 1549-byte module CRC were verified. The TI module
was rebuilt from the current source. DOSBox checks covered huge-pointer segment
crossings, CPU/FPU selection, and clean startup failure without a TIGA board.
Actual TIGA graphics/transport/page flipping has not been tested here.
