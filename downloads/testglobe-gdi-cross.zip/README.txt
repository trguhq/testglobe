Windows GDI / Windows 3.1

testglobe development cross-build, 2026-11-07

Source and build instructions:
https://github.com/trguhq/testglobe/tree/develop
Use the repository revision containing this ZIP to obtain its corresponding source.
Application source license: GPL-3.0-or-later (see LICENSE).

This build fixes polygon coverage and FPS reporting in the Win16 GDI renderer:
- FPS updates after each timed frame, without a sixty-frame startup delay.
- Every PolyPolygon contour explicitly repeats its first vertex.
- A reusable monochrome fill-and-outline mask preserves dithering at boundaries.
- Mask failure falls back to nearest solid colors with matching outlines;
  allocation failure can use matching stock black/white brushes and pens.

Compiler: OpenWatcom 2.0 beta, Linux x64 host
Build: make gdi-cross

Requirements: Windows 3.1 protected mode (286 or later), 256-color Windows GDI.
An x87 is optional; the standard Windows math-emulation runtime is supported.
Launch TESTGLOB.EXE from Windows File Manager. All Earth data is embedded.
The program retains the original single-instance policy.

Keys 1-5 select Earth resolution; default is 1 (32-wide). A toggles automatic
rotation; F toggles FPS; O toggles OSD; Escape exits. There is no texture mode.

This is a genuine 16-bit NE executable. OpenWatcom uses its large-model Windows
runtime, with explicit huge pointers for cross-segment mesh/data access.

Validation:
- OpenWatcom compilation and linking completed successfully.
- Windows 3.1 NE headers, imports, and all 13 embedded Earth resources verified.
- Host regression checks cover GDI, OpenGL, and shared application code, including
  FPS sampling, contour closure, mask/pen operations, failure recovery, and
  resource ownership.
- Native Windows 3.1 execution and pixel output remain untested in this environment.
