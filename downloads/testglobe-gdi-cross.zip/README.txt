Windows GDI / Windows 3.1

testglobe development cross-build, 2026-11-07

Source and build instructions:
https://github.com/trguhq/testglobe/tree/develop
Use the repository revision containing this ZIP to obtain its corresponding source.
Application source license: GPL-3.0-or-later (see LICENSE).

Validation:
- All four actual cross-build targets compiled and linked successfully.
- Executable formats and required embedded Earth data were inspected.
- Full host regression suite passed (1,363 PASS results), including the existing
  drivers, SDK contracts, geometry, resource lifetimes, and DOS CPU probe.
- The original Linux OpenGL target still compiles and links.
- Host tests do not establish physical graphics output or native desktop behavior.

Compiler: OpenWatcom 2.0 beta, 2026-11-06 Linux x64 host

Build: make gdi-cross

Requirements: Windows 3.1 protected mode (286 or later), standard Windows GDI.
An x87 is optional; the standard Windows math-emulation runtime is supported.
Launch TESTGLOB.EXE from Windows File Manager. All Earth data is embedded.
The program retains the original single-instance policy.

Keys 1-5 select Earth resolution; default is 1 (32-wide). A toggles automatic
rotation; F toggles FPS; O toggles OSD; Escape exits. There is no texture mode.

This is a genuine 16-bit NE executable. OpenWatcom uses its large-model Windows
runtime, with explicit huge pointers for cross-segment mesh/data access. All 13
Earth RCDATA resources were checked byte-for-byte against the source data.
Actual Windows launch/rendering has not been tested in this environment.
