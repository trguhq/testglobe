testglobe 0.2.2 - Linux, OpenGL/GLUT for x86-64, x86, ARM64 and ARMv7

testglobe 0.2.2 development build, 2026-11-28

Built from source revision a93349b38a3dd65a1eb5eee0cf7cf27264999cad.
Source: https://github.com/trguhq/testglobe/tree/a93349b38a3dd65a1eb5eee0cf7cf27264999cad
Application source license: GPL-3.0-or-later (see LICENSE).
Build: make opengl with GCC 13.3 (native and cross) against Ubuntu 20.04
libraries (glibc 2.31, freeglut 2.8.1), one build per architecture

testglobe is one file for four architectures: a short sh script followed by
an x86-64, an i686 (32-bit x86), an ARM64 and an ARMv7 hard-float build. It
picks the build for the machine (a 32-bit system on a 64-bit kernel, such as
32-bit Raspberry Pi OS, gets the 32-bit build), unpacks it to a temporary
directory, runs it and removes the copy. Run it from a terminal:
  ./testglobe
It needs an X11 or XWayland display, glibc 2.29 or later (Ubuntu 20.04,
Debian 11, Raspberry Pi OS 11, Fedora 31, RHEL 9 or newer), and the OpenGL,
GLU and GLUT (freeglut) libraries for that architecture, for example:
  Debian, Ubuntu, Raspberry Pi OS: freeglut3 or libglut3.12, libglu1-mesa
  Fedora: freeglut, mesa-libGLU     Arch: freeglut, glu
freeglut 3.4 and later name the library libglut.so.3.12; the script offers it
under the older name libglut.so.3 that the builds use. ARMv6 boards (the
original Raspberry Pi and Pi Zero) are not supported.

Options, as environment variables:
  TESTGLOBE_ARCH=x86_64|i386|arm64|armhf  choose a build
  TESTGLOBE_EXTRACT=FILE                  write the chosen build to FILE
  TMPDIR=DIR                              unpack there; it must allow running
                                          programs (XDG_RUNTIME_DIR comes first)

Keys 1-5 select the globe resolution; T toggles texture mapping, C culling,
D display lists, A automatic rotation, F the FPS and O the OSD; Escape exits.
See docs/opengl.md.

Validation: through this script, the x86-64 and i686 builds ran on Ubuntu
24.04 (freeglut 3.4, so through the libglut.so.3.12 fallback) under Xvfb with
Mesa's software renderer, and the ARM64 and ARMv7 builds ran under QEMU user
emulation with Ubuntu 20.04's libraries; each drew the globe. The script's
CPU detection was checked for each machine type listed above. They have not
yet run on physical ARM boards or with a hardware OpenGL driver.
