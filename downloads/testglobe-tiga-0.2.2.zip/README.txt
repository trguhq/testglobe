testglobe 0.2.2 - DOS, TIGA 2.x boards

testglobe 0.2.2 development build, 2026-11-28

Built from source revision a93349b38a3dd65a1eb5eee0cf7cf27264999cad.
Source: https://github.com/trguhq/testglobe/tree/a93349b38a3dd65a1eb5eee0cf7cf27264999cad
Application source license: GPL-3.0-or-later (see LICENSE).
Build: make tiga-cross (OpenWatcom 2.0 beta, Nov 27 2026; TI TMS340 Code
Generation Tools 5.01 under DOSBox; TIGA SDK 2.01 ai.lib)

Requirements: real-mode MS-DOS and a TIGA 2.x installation for the board:
the vendor's TIGACD.EXE communication driver, graphics manager and standard
extprims.rlm must be installed and configured. The board needs a 640x480
mode with 8 valid pixel bits and a programmable 256-color palette; the
driver finds it by querying modes. A Microsoft-compatible mouse driver
enables dragging.

TESTGLOB.EXE carries its TI transform module appended to the executable;
nothing else needs copying. When S first selects TI transforms, the module
is written to a temporary file in TEMP, TMP or the current directory, loaded
and deleted, so one of those must be writable.

Keys 1-2 select the globe resolution, S switches between host and TI
transforms (host transforms are the default), A/F/O toggle rotation, FPS
and the OSD, and Escape, Ctrl-C or Ctrl-Break exits. See docs/tiga.md.

Validation: built on a Linux host and checked with the repository's host
tests (driver call recorders, shared geometry and resource checks) and
tests/cross_binary.py where it covers the format. It has not been run on
the target hardware in this environment.
