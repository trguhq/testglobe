Matrox LibShell / real-mode DOS, 640x480 indexed color

testglobe development cross-build, 2026-11-07

Source and build instructions:
https://github.com/trguhq/testglobe/tree/develop
Use the repository revision containing this ZIP to obtain its corresponding source.
Application source license: GPL-3.0-or-later (see LICENSE).

Validation:
- All four actual cross-build targets compiled and linked successfully.
- Executable formats and required embedded Earth data were inspected.
- Full host regression suite passed (1,363 PASS results), including the existing
  drivers, SDK contracts, geometry, resource lifetimes, and DOS CPU probe.
- The original Linux OpenGL target still compiles and links.
- Host tests do not establish physical graphics output or native desktop behavior.

Compiler: OpenWatcom 2.0 beta, 2026-11-06 Linux x64 host

Build: make matrox-cross

Requirements: DOS, 286 or later, PG-641-compatible Matrox hardware, initialized
firmware and LibShell environment. The supplied LSCL.LIB contains 286 instructions;
the application refuses an older CPU before entering that library. No x87 is
required. TESTGLOB.EXE embeds both Earth maps and needs no separate map files.

LibShell 3D transforms are the default. S toggles host transforms while LibShell
continues filling polygons. Recoverable native transform failures can fall back
to the host path. Keys 1-2 select Earth resolution; default is 1. A/F/O toggle
rotation/FPS/OSD; Escape exits. There is no texture mode.

The Microsoft-built LibShell binding is linked through src/mtx_ow.c adapters.
The real library's world-window, 3D polygon, screen polygon, integer/floating,
pointer, and variadic boundaries passed DOSBox checks with x87 and forced Watcom
software emulation. Both embedded maps and MZ relocations were verified.
Actual Matrox graphics/communications have not been tested here.

LibShell build input SHA256:
6e0412d65871635ac0fa825085782022217d200a5f2e1e1352f031793974f710
The vendor SDK/library itself is not included in this ZIP.
