testglobe 0.2.2 - Amiga, chipset and RTG software rendering

testglobe 0.2.2 development build, 2026-11-28

Built from source revision a93349b38a3dd65a1eb5eee0cf7cf27264999cad.
Source: https://github.com/trguhq/testglobe/tree/a93349b38a3dd65a1eb5eee0cf7cf27264999cad
Application source license: GPL-3.0-or-later (see LICENSE).
Build: make amiga (VBCC 0.9h patch 3, vasm 2.0f, vlink 0.18a, NDK 3.2 R4 headers)

Requirements: AmigaOS 1.3 or later on a 68000 or later with OCS, ECS or AGA
(1-8 bitplanes); optional RTG through CyberGraphX or Picasso96 and optional
fullscreen on AmigaOS 3.0 or later. No FPU is required.

Copy testglobe-amiga and testglobe-amiga.info to the same directory and
double-click the icon, which selects a 32768-byte stack. From a Shell:
  Stack 32768
  testglobe-amiga
All Earth maps are embedded in the executable's debug records; do not strip
them. Keys 1-5 select the globe resolution; A, P, O, D and F toggle
rotation, FPS, the OSD, dithering and fullscreen; Escape exits. See
docs/amiga.md.

Validation: built on a Linux host and checked with the repository's host
tests (driver call recorders, shared geometry and resource checks) and
tests/cross_binary.py where it covers the format. It has not been run on
the target hardware in this environment.
