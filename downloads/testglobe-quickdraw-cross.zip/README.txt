QuickDraw / classic Macintosh System 7, 68000

testglobe development cross-build, 2026-11-07

Source and build instructions:
https://github.com/trguhq/testglobe/tree/develop
Use the repository revision containing this ZIP to obtain its corresponding source.
Application source license: GPL-3.0-or-later (see LICENSE).

Validation:
- All four actual cross-build targets compiled and linked successfully.
- Executable formats and required embedded Earth data were inspected.
- Full host regression suite passed (1,363 PASS results), including the existing
  drivers, SDK contracts, geometry, resource lifetimes, and DOS CPU probe.
- The original Linux OpenGL target still compiles and links.
- Host tests do not establish physical graphics output or native desktop behavior.

Compiler: Retro68 GCC 16.1.0; official image sha256:dd923969100f408943f73c9618b3c7628686aae819583eecb0ddd1837da6943c

Build: make quickdraw-cross

Requirements: Macintosh System 7, 68000 or later. No FPU is required.
TestglobeQD.bin is MacBinary: decode with a MacBinary-aware utility, preserving
its resource fork, then launch the resulting application. TestglobeQD.dsk is an
800KiB HFS disk image containing the same application for emulator/media use.
Neither container is a separate data dependency: the application embeds all maps.

Keys 1-5 select Earth resolution; default is 1 (32-wide). A toggles automatic
rotation; F toggles FPS; O toggles OSD; Escape exits. There is no texture mode.
The driver adapts desktop color depth and reports GWorld use in the OSD.

The baseline is 68000/software floating point. Runtime-guarded 68020/68881
helpers contain the optional FPU code. Linked code was inspected for this
separation and avoids FINTRZ and FPU transcendental opcodes. All 13 EART resources,
nine CODE resources, and application SIZE/type/creator were verified.
Actual Macintosh launch/rendering has not been tested in this environment.
