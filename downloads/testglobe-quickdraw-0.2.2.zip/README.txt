testglobe 0.2.2 - Classic Macintosh, System 7 QuickDraw, 68000 and later

testglobe 0.2.2 development build, 2026-11-28

Built from source revision a93349b38a3dd65a1eb5eee0cf7cf27264999cad.
Source: https://github.com/trguhq/testglobe/tree/a93349b38a3dd65a1eb5eee0cf7cf27264999cad
Application source license: GPL-3.0-or-later (see LICENSE).
Build: make quickdraw-cross (Retro68, GCC 16.1.0, Multiversal interfaces)

TestglobeQD.bin is a MacBinary file that keeps the resource fork; decode it
with a MacBinary-aware utility. TestglobeQD.dsk is an 800 KiB HFS disk image
containing the same application. The application asks for an 8 MiB
preferred and 512 KiB minimum partition; a 68881 is used when present.

Keys 1-5 select the globe resolution; A, F and O toggle rotation, FPS and
the OSD; File > Quit or Command-Q quits. See docs/quickdraw.md.

Validation: built on a Linux host and checked with the repository's host
tests (driver call recorders, shared geometry and resource checks) and
tests/cross_binary.py where it covers the format. It has not been run on
the target hardware in this environment.
