Testglobe - native Amiga chipset / RTG build
Source revision: 50a89c3087a5acc514fa9ce246553b3e4862201c (develop)
Source: https://github.com/trguhq/testglobe/tree/50a89c3087a5acc514fa9ce246553b3e4862201c

Files:
  testglobe-amiga       Amiga Hunk executable; all Earth maps embedded
  testglobe-amiga.info  Classic Workbench tool icon; 32768-byte launch stack

Copy both files to the same directory on your Amiga and double-click the icon.
For an Amiga Shell launch:
  Stack 32768
  testglobe-amiga
If file transfer loses the executable protection flag:
  Protect testglobe-amiga +e
Keep the executable available while running; selected globe maps are read from it.
Do not strip debug records: they contain the embedded map data.

Native path: AmigaOS 1.3 or later, 68000 or later, OCS/ECS/AGA Workbench.
Optional RTG: AmigaOS 3.0 or later with CyberGraphX V40 or Picasso96API V2;
8-bit indexed and 15/16/24/32-bit truecolor desktops. Native rendering remains
available without RTG libraries. No FPU is required. CPU/FPU detection selects
baseline integer, 68020 integer, or compatible hardware-FPU transforms.
Default globe resolution is 32 x 16 (key 1); keys 1 through 5 select resolution.
No texture mapping or OpenGL library is needed.

Built with VBCC 0.9h / m68k generator 1.15, vasm 1.9d, vlink 0.17a,
NDK 47.5 headers and the kick13 runtime. Build target: make amiga AMI_RTG=1.
Baseline code: -cpu=68000 -fpu=0 -rmcfg-amiga-softfloat, linked with -lmsoft.
Separate 68020 integer and 68881-compatible FPU helpers are selected at runtime.

Validation: cross-build and host Amiga regression tests passed, including
CPU/FPU dispatch, chipset/RTG paths, resource loading, and icon/stack checks.
The delivered executable's Hunk structure and all 13 embedded data chunks were
validated. Not executed on Amiga hardware or an Amiga emulator.

See LICENSE and the source repository for licensing and full build instructions.
