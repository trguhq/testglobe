testglobe 0.2.3 - DOS, Matrox LIB Shell boards and IBM PGC-compatible boards

testglobe 0.2.3 development build, 2026-11-28

Built from source revision 6b78013eba4ccb3dc8ed763fde913b9444961f10.
Source: https://github.com/trguhq/testglobe/tree/6b78013eba4ccb3dc8ed763fde913b9444961f10
Application source license: GPL-3.0-or-later (see LICENSE).
Build: make matrox-cross (OpenWatcom 2.0 beta, Nov 27 2026), no Matrox files

Requirements: MS-DOS on an 8086 or later, 256 colors, and one of:
- a Matrox board running the LIB Shell (PG Series 1 such as the PG-641,
  PG-1024 or PG-1281, or the PG2-1281). Download the LIB Shell first, for
  example with pgdownl ls.out; set PG1281 if the board is not at C600h.
- an IBM PGC or compatible board such as the Matrox PG-640A, with its
  communication area at C6000h or C6400h.
The board reports its screen size; 640x480 to 2048x2048 is supported.
No x87 is required; one is used when present. A Microsoft-compatible mouse
driver enables dragging.

Run TESTGLOB.EXE. Keys 1-2 select the globe resolution, S switches between
board and host transforms, A/F/O toggle rotation, FPS and the OSD, and
Escape, Ctrl-C or Ctrl-Break exits. LIB Shell boards use their full
4096-word command FIFO; set MTXFIFO=256 (bytes) for smaller groups if a
board misbehaves. See docs/matrox.md.

Validation: built on a Linux host and checked with the repository's host
tests (driver call recorders, shared geometry and resource checks) and
tests/cross_binary.py where it covers the format. It has not been run on
the target hardware in this environment.
