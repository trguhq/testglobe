testglobe 0.2.2 - Amiga, PiStorm3D through MiniGL

testglobe 0.2.2 development build, 2026-11-28

Built from source revision a93349b38a3dd65a1eb5eee0cf7cf27264999cad.
Source: https://github.com/trguhq/testglobe/tree/a93349b38a3dd65a1eb5eee0cf7cf27264999cad
Application source license: GPL-3.0-or-later (see LICENSE).
Build: make amiga-opengl (VBCC 0.9h patch 3, vasm 2.0f, vlink 0.18a, NDK 3.2 R4
headers, MiniGL SDK MiniGL_Classic d950a3a1)

Requirements: AmigaOS 3.x on a PiStorm (Raspberry Pi 4, CM4 or 4B), RTG
graphics with cybergraphics.library V40 or later, and PiStorm3D's shared
minigl.library V29 with dispatch ABI 5 installed as LIBS:minigl.library.
Built for a 68020 with 68881 floating point.

Copy testglobe-amiga-opengl and its .info icon to the same directory and
double-click the icon, which selects a 131072-byte stack. Keys 1-5 select
the globe resolution; T toggles texture mapping; A, F and O toggle
rotation, FPS and the OSD; Escape exits. See docs/opengl.md.

Validation: built on a Linux host and checked with the repository's host
tests (driver call recorders, shared geometry and resource checks) and
tests/cross_binary.py where it covers the format. It has not been run on
the target hardware in this environment.
