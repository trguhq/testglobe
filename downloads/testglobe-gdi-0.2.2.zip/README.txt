testglobe 0.2.2 - Windows 3.0 and 3.1, GDI

testglobe 0.2.2 development build, 2026-11-28

Built from source revision a93349b38a3dd65a1eb5eee0cf7cf27264999cad.
Source: https://github.com/trguhq/testglobe/tree/a93349b38a3dd65a1eb5eee0cf7cf27264999cad
Application source license: GPL-3.0-or-later (see LICENSE).
Build: make gdi-cross (OpenWatcom 2.0 beta, Nov 27 2026)

Requirements: Windows 3.0 in standard or 386 enhanced mode, or Windows 3.1,
in a 256-color display mode. An x87 is optional; the standard Windows math
emulation is used without one.

Launch TESTGLOB.EXE from File Manager or Program Manager. All Earth data is
embedded. Keys 1-5 select the globe resolution; A, F and O toggle rotation,
FPS and the OSD; Escape exits. See docs/gdi.md.

Validation: built on a Linux host and checked with the repository's host
tests (driver call recorders, shared geometry and resource checks) and
tests/cross_binary.py where it covers the format. It has not been run on
the target hardware in this environment.
